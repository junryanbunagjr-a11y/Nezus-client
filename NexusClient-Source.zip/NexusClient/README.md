# Nexus Client

A lightweight Fabric client-side HUD/ClickGUI starter for Minecraft Java 1.21.11.

## Included
- Right Shift opens the ClickGUI
- FPS display
- CPS counter
- Basic WASD/Space key display
- Optional coordinates
- Click rows in the GUI to toggle HUD elements

## Build without a PC
1. Create a GitHub account and a new **public** repository named `nexus-client`.
2. Upload all files and folders from this project, preserving their paths.
3. Open the repository's **Actions** tab.
4. Select **Build Nexus Client** and press **Run workflow** (or push to `main`).
5. Open the completed workflow run, scroll to **Artifacts**, and download `nexus-client`.
6. Extract the downloaded artifact ZIP. The mod `.jar` is inside.
7. Put the `.jar` in the `mods` folder for your Fabric 1.21.11 instance. Fabric API must also be installed.

## Notes
This is a starter client, not a full Corz replacement. It does not include combat automation or server exploit features. Build errors can happen if upstream Minecraft/Fabric APIs have changed; if Actions reports an error, share the log so it can be fixed.
