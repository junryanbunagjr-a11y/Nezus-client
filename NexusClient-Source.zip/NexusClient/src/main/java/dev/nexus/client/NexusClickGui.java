package dev.nexus.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class NexusClickGui extends Screen {
    private static final int PANEL = 0xE0181B24;
    private static final int ACCENT = 0xFF55D7FF;
    private static final int TEXT = 0xFFFFFFFF;

    public NexusClickGui() { super(Text.literal("Nexus Client")); }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        this.renderBackground(ctx, mouseX, mouseY, delta);
        int x = this.width / 2 - 115;
        int y = this.height / 2 - 92;
        ctx.fill(x, y, x + 230, y + 184, PANEL);
        ctx.fill(x, y, x + 230, y + 2, ACCENT);
        ctx.drawText(this.textRenderer, "NEXUS CLIENT", x + 12, y + 12, ACCENT, false);
        ctx.drawText(this.textRenderer, "HUD MODULES", x + 12, y + 34, 0xFFAAAAAA, false);

        drawToggle(ctx, x + 12, y + 55, "FPS HUD", NexusClient.showFps);
        drawToggle(ctx, x + 12, y + 77, "CPS COUNTER", NexusClient.showCps);
        drawToggle(ctx, x + 12, y + 99, "KEYSTROKES", NexusClient.showKeys);
        drawToggle(ctx, x + 12, y + 121, "COORDINATES", NexusClient.showCoords);

        ctx.drawText(this.textRenderer, "Click a row to toggle  |  ESC to close",
                x + 12, y + 158, 0xFFAAAAAA, false);
        super.render(ctx, mouseX, mouseY, delta);
    }

    private void drawToggle(DrawContext ctx, int x, int y, String name, boolean enabled) {
        ctx.fill(x, y - 4, x + 206, y + 16, 0xFF252B36);
        ctx.drawText(this.textRenderer, name, x + 7, y, TEXT, false);
        ctx.drawText(this.textRenderer, enabled ? "ON" : "OFF",
                x + 178, y, enabled ? 0xFF55E69A : 0xFFFF7777, false);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        int x = this.width / 2 - 103;
        int y = this.height / 2 - 37;
        if (mouseX >= x && mouseX <= x + 206) {
            if (mouseY >= y && mouseY < y + 20) NexusClient.showFps = !NexusClient.showFps;
            else if (mouseY >= y + 22 && mouseY < y + 42) NexusClient.showCps = !NexusClient.showCps;
            else if (mouseY >= y + 44 && mouseY < y + 64) NexusClient.showKeys = !NexusClient.showKeys;
            else if (mouseY >= y + 66 && mouseY < y + 86) NexusClient.showCoords = !NexusClient.showCoords;
        }
        return true;
    }

    @Override
    public boolean shouldPause() { return false; }
}
