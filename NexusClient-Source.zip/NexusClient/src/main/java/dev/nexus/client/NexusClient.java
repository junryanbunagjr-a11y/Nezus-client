package dev.nexus.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class NexusClient implements ClientModInitializer {
    public static boolean showFps = true;
    public static boolean showCps = true;
    public static boolean showKeys = true;
    public static boolean showCoords = false;

    private KeyBinding openGui;
    private boolean wasDown = false;
    private int leftClicks = 0;
    private int rightClicks = 0;
    private long cpsWindow = System.currentTimeMillis();
    private int leftCps = 0;
    private int rightCps = 0;
    private boolean leftWasDown = false;
    private boolean rightWasDown = false;

    @Override
    public void onInitializeClient() {
        var category = KeyBinding.Category.create(Identifier.of("nexusclient", "main"));
        openGui = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.nexusclient.gui", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT, category));

        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
        HudRenderCallback.EVENT.register((draw, tickCounter) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player == null) return;
            int y = 8;
            draw.drawText(client.textRenderer, "NEXUS", 8, y, 0xFF55D7FF, true);
            y += 12;
            if (showFps) {
                draw.drawText(client.textRenderer, "FPS: " + client.getCurrentFps(), 8, y, 0xFFFFFFFF, true);
                y += 11;
            }
            if (showCps) {
                draw.drawText(client.textRenderer, "CPS: " + leftCps + " | " + rightCps, 8, y, 0xFFFFFFFF, true);
                y += 11;
            }
            if (showKeys) {
                String keys = keyState(client);
                draw.drawText(client.textRenderer, keys, 8, y, 0xFFFFFFFF, true);
                y += 11;
            }
            if (showCoords) {
                var p = client.player.getBlockPos();
                draw.drawText(client.textRenderer, "XYZ: " + p.getX() + " " + p.getY() + " " + p.getZ(),
                        8, y, 0xFFFFFFFF, true);
            }
        });
    }

    private void tick(MinecraftClient client) {
        if (openGui.isPressed() && !wasDown && client.currentScreen == null) {
            client.setScreen(new NexusClickGui());
        }
        wasDown = openGui.isPressed();

        if (client.getWindow() == null) return;
        long handle = client.getWindow().getHandle();
        boolean l = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean r = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        if (l && !leftWasDown) leftClicks++;
        if (r && !rightWasDown) rightClicks++;
        leftWasDown = l;
        rightWasDown = r;

        long now = System.currentTimeMillis();
        if (now - cpsWindow >= 1000) {
            leftCps = leftClicks;
            rightCps = rightClicks;
            leftClicks = rightClicks = 0;
            cpsWindow = now;
        }
    }

    private String keyState(MinecraftClient c) {
        if (c.player == null) return "";
        var opts = c.options;
        return "[W " + down(opts.forwardKey) + "] [A " + down(opts.leftKey) +
                "] [S " + down(opts.backKey) + "] [D " + down(opts.rightKey) +
                "] [SPACE " + down(opts.jumpKey) + "]";
    }

    private String down(KeyBinding key) { return key.isPressed() ? "■" : "□"; }
}
